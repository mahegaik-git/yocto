create_partition()
{
cat << EOM
################################################################################
		Now making 4 partitions
################################################################################
EOM
	dd if=/dev/zero of=$DRIVE bs=1024 count=1024
	SIZE=`fdisk -l $DRIVE | grep Disk | awk '{print $5}'`
	echo DISK SIZE - $SIZE bytes

        echo "-----------------------------"
sfdisk "${DRIVE}" <<-__EOF__
                        ,100M,c,*
			,1G,L
                        ,1G,L
                        ;
__EOF__
        echo "-----------------------------"
}

create_filesystem_lable()
{
#      message="mkfs.ext4 /dev/mmcblk1p1 -L root" ; broadcast
	echo "creating labels----------------"
	mkfs.vfat -F 32 -n "boot" ${DRIVE}1
	mkfs.ext4  -F ${DRIVE}2 -L "Root"

	mkfs.ext4  -F ${DRIVE}3  -L "Backup_root"

	mkfs.ext4  -F ${DRIVE}4 -L "Upgrade"
	echo "-----------------------------"
}

###########################################################################
#  This function validates the Images path provided by the user, before   #
#  actually formatting the SD card.                                       #
#  User needs to enter the path of the images (boot+rootfs)               #
#  Also needs to enter if it is prod or test rootfs image so that         #
#  the right rootfs is picked up.                                         #
###########################################################################


copy_boot_rootfs()
{
	PWD=`pwd`
	echo "------------------------------"
	echo "Now need to provide  the path for the images"

	ENTERCORRECTLY=0
	while [ $ENTERCORRECTLY -ne 1 ]
	do
		read -p 'Enter path for images : '  IMAGEFILEPATH
		if [ -d $IMAGEFILEPATH/boot ]
		then
			echo "Directory exists"
			echo ""
			echo "This directory contains:"
			ls $IMAGEFILEPATH/boot
			echo ""
			read -p 'Is this correct? [y/n] : ' ISRIGHTPATH
				case $ISRIGHTPATH in
				"y") ENTERCORRECTLY=1;;
				"n") ENTERCORRECTLY=0;;
				*)  echo "Please enter y or n";ENTERCORRECTLY=0;;
				esac
		else
			echo "Invalid path make sure to include complete path"
			exit 1

			ENTERCORRECTLY=0
		fi
    	done



	read -p 'Enter "prod" or "test" rootfs : '  TYPE
	if [ $TYPE = "test" ]
	then
		if [ -f $IMAGEFILEPATH/fsp-image-test-*.tar.xz ]
		then
			echo "**********************fsp-image-test-*.tar.xz exists***************************"
			test=true
		else

			echo " File does not exist: quitting"
			exit 1

		fi
	fi

	if [ $TYPE = "prod" ]
	then
		if [ -f $IMAGEFILEPATH/fsp-image-prod-*.tar.xz ]
		then

			echo "********************fsp-image-prod-*.tar.xz exists*******************************"
			prod=true
		else

			echo " File does not exist: quitting"
			exit 1
		fi
	fi


	echo "-----------------------------"
	# Make temporary directories and untar mount the partitions

        # create_partitions only when files exist.
	create_partition
	create_filesystem_lable

	mkdir $PWD/bootfiles
	mkdir $PWD/rootfs
	mkdir $PWD/rootfs_back
	mount -t vfat "${DRIVE}""1" bootfiles
	mount -t ext4 "${DRIVE}""2" rootfs
	mount -t ext4 "${DRIVE}""3" rootfs_back
	echo "-----------------------------"


	echo "-----------------------------"
	echo "Copying Boot files"
	echo "-----------------------------"

	cp $IMAGEFILEPATH/boot/MLO 	    $PWD/bootfiles/
	cp $IMAGEFILEPATH/boot/u-boot.img  $PWD/bootfiles/
	cp $IMAGEFILEPATH/boot/uEnv.txt    $PWD/bootfiles/
	echo "-----------------------------"


	echo "-----------------------------"
	echo "Copying rootfs "
	echo "-----------------------------"
	if [ $TYPE = "prod" ]
	then

		echo "Copying prod rootfs "
		tar -xf $IMAGEFILEPATH/fsp-image-prod-*.tar.xz -C $PWD/rootfs
		tar -xf $IMAGEFILEPATH/fsp-image-prod-*.tar.xz -C $PWD/rootfs_back

	elif [ $TYPE = "test" ]
	then

		echo "Copying test rootfs "
		tar -xf $IMAGEFILEPATH/fsp-image-test-*.tar.xz -C $PWD/rootfs
		tar -xf $IMAGEFILEPATH/fsp-image-test-*.tar.xz -C $PWD/rootfs_back
	else

		echo"not a valid rootfs & exiting"
		exit 1

	fi
	echo "-----------------------------"

	umount bootfiles rootfs rootfs_back
	sync;sleep 10;sync;sleep 10;sync

	# Clean up the temp directories
	rm -rf bootfiles rootfs rootfs_back

}
cat << EOM
################################################################################
This script will create a bootable SD card from yocto images.
The script must be run with root permissions.
Example:
 $ sudo ./create-platform-sdcard.sh
Formatting can be skipped if the SD card is already formatted and
partitioned properly.
################################################################################
EOM

AMIROOT=`whoami | awk {'print $1'}`
if [ "$AMIROOT" != "root" ] ; then

	echo "	**** Error *** must run script with sudo"
	echo ""
	exit
fi


# find the avaible SD cards
echo " "
echo "Availible Drives to write images to: "
echo " "
ROOTDRIVE=`mount | grep 'on / ' | awk {'print $1'} |  cut -c6-8`
echo "#  major   minor    size   name "
cat /proc/partitions | grep -v $ROOTDRIVE | grep '\<sd.\>' | grep -n ''
echo " "


ENTERCORRECTLY=0
while [ $ENTERCORRECTLY -ne 1 ]
do
	read -p 'Enter Device Number: ' DEVICEDRIVENUMBER
	echo " "
	DEVICEDRIVENAME=`cat /proc/partitions | grep -v 'sda' | grep '\<sd.\>' | grep -n '' | grep "${DEVICEDRIVENUMBER}:" | awk '{print $5}'`

	DRIVE=/dev/$DEVICEDRIVENAME
	DEVICESIZE=`cat /proc/partitions | grep -v 'sda' | grep '\<sd.\>' | grep -n '' | grep "${DEVICEDRIVENUMBER}:" | awk '{print $4}'`


	if [ -n "$DEVICEDRIVENAME" ]
	then
		ENTERCORRECTLY=1
	else
		echo "Invalid selection"
	fi

	echo ""
done

echo "$DEVICEDRIVENAME was selected"
#Check the size of disk to make sure its under 16GB
if [ $DEVICESIZE -gt 17000000 ] ; then
cat << EOM
################################################################################
		**********WARNING**********
	Selected Device is greater then 16GB
	Continuing past this point will erase data from device
	Double check that this is the correct SD Card
################################################################################
EOM

	ENTERCORRECTLY=0
	while [ $ENTERCORRECTLY -ne 1 ]
	do
		read -p 'Would you like to continue [y/n] : ' SIZECHECK
		echo ""
		echo " "
		ENTERCORRECTLY=1
		case $SIZECHECK in
		"y")  ;;
		"n")  exit;;
		*)  echo "Please enter y or n";ENTERCORRECTLY=0;;
		esac
		echo ""
	done

fi

echo ""


DRIVE=/dev/$DEVICEDRIVENAME

echo "Checking the device is unmounted"
#unmount drives if they are mounted
unmounted1=`df | grep '\<'$DEVICEDRIVENAME'1\>' | awk '{print $1}'`
unmounted2=`df | grep '\<'$DEVICEDRIVENAME'2\>' | awk '{print $1}'`
unmounted3=`df | grep '\<'$DEVICEDRIVENAME'3\>' | awk '{print $1}'`
unmounted4=`df | grep '\<'$DEVICEDRIVENAME'4\>' | awk '{print $1}'`

if [ -n "$unmounted1" ]
then
	echo " unmounted ${DRIVE}1"
	sudo umount -f ${DRIVE}1
fi
if [ -n "$unmounted2" ]
then
	echo " unmounted ${DRIVE}2"
	sudo umount -f ${DRIVE}2
fi
if [ -n "$unmounted3" ]
then
	echo " unmounted ${DRIVE}3"
	sudo umount -f ${DRIVE}3
fi
if [ -n "$unmounted4" ]
then
	echo " unmounted ${DRIVE}4"
	sudo umount -f ${DRIVE}4
fi

echo ""

# check to see if the device is already partitioned
SIZE1=`cat /proc/partitions | grep -v 'sda' | grep '\<'$DEVICEDRIVENAME'1\>'  | awk '{print $3}'`
SIZE2=`cat /proc/partitions | grep -v 'sda' | grep '\<'$DEVICEDRIVENAME'2\>'  | awk '{print $3}'`
SIZE3=`cat /proc/partitions | grep -v 'sda' | grep '\<'$DEVICEDRIVENAME'3\>'  | awk '{print $3}'`
SIZE4=`cat /proc/partitions | grep -v 'sda' | grep '\<'$DEVICEDRIVENAME'4\>'  | awk '{print $3}'`

echo "${DEVICEDRIVENAME}1  ${DEVICEDRIVENAME}2   ${DEVICEDRIVENAME}3 ${DEVICEDRIVENAME}4"
echo $SIZE1 $SIZE2 $SIZE3 $SIZE4
echo ""

copy_boot_rootfs
