#!/bin/bash

BOARD=am335x-evm
IMAGE_FILENAME=fsp-image-test-am335x-evm.tar.xz
IMAGE_PROD_FILENAME=fsp-image-prod-am335x-evm.tar.xz
if [[ $# -eq 0 ]]; then  
    echo "BOARD = am335x-evm"
elif [[ "$2" = "beaglebone" ]]; then
    echo "BOARD = beaglebone"
    BOARD=$2
    IMAGE_FILENAME=fsp-image-test-beaglebone.tar.xz
    IMAGE_PROD_FILENAME=fsp-image-prod-beaglebone.tar.xz
elif [[ "$2" = "am437x-evm" ]]; then
    echo "BOARD = am437x-evm"
    BOARD=$2
    IMAGE_FILENAME=fsp-image-test-am437x-evm.tar.xz
    IMAGE_PROD_FILENAME=fsp-image-prod-am437x-evm.tar.xz
else
    echo "BOARD = am335x-evm"
fi

#if [ ! -d "../${BOARD}" ]; then
#    mkdir ../${BOARD}
#fi

VM_ADDRESS=platform-images@40.76.195.152
IMAGE_FILE_PATH=/home/platform-images/fsp-builds/$1/${BOARD}
                
BOOT_DIR_NAME=boot
ROOTFS_DIR_NAME_TEST=rootfs-test
ROOTFS_DIR_NAME_PROD=rootfs-prod

# Remove earlier image (if present any)
if [ -f ../${IMAGE_FILENAME} ] 
then
	rm ../${IMAGE_FILENAME}
fi

# Get the image from the VM 
scp -i ~/.ssh/id_rsa.pub ${VM_ADDRESS}:${IMAGE_FILE_PATH}/${IMAGE_FILENAME} ../
#scp -i ~/.ssh/id_rsa.pub ${VM_ADDRESS}:${IMAGE_FILE_PATH}/${IMAGE_PROD_FILENAME} ../

if [ $? -eq 0 ]
then 
	echo "File copied successfully. Proceeding further."
	if [ -d ../${ROOTFS_DIR_NAME_TEST} ]
	then
		rm -rf ../${ROOTFS_DIR_NAME_TEST}
	fi
	mkdir ../${ROOTFS_DIR_NAME_TEST}
	
	tar -xvf ../${IMAGE_FILENAME} -C ../${ROOTFS_DIR_NAME_TEST}

	if [ -d ../${ROOTFS_DIR_NAME_PROD} ]
	then
		rm -rf ../${ROOTFS_DIR_NAME_PROD}
	fi
	mkdir ../${ROOTFS_DIR_NAME_PROD}
	
	tar -xvf ../${IMAGE_FILENAME} -C ../${ROOTFS_DIR_NAME_PROD}


	if [ -d ../${BOOT_DIR_NAME} ]
	then
		rm -rf ../${BOOT_DIR_NAME}
	fi
	mkdir ../${BOOT_DIR_NAME}

	# scp MLO and u-boot from Yocto image to boot on beaglebone hardware. 
	scp -i ~/.ssh/id_rsa.pub ${VM_ADDRESS}:${IMAGE_FILE_PATH}/MLO ../${BOOT_DIR_NAME}
	scp -i ~/.ssh/id_rsa.pub ${VM_ADDRESS}:${IMAGE_FILE_PATH}/u-boot.img ../${BOOT_DIR_NAME}
	scp -i ~/.ssh/id_rsa.pub ${VM_ADDRESS}:${IMAGE_FILE_PATH}/uEnv.txt ../${BOOT_DIR_NAME}

   # cp FSP Test UI application
#	mkdir ../rootfs/home/root/bin
#	cp	/home/platform-dev/projects/FSP/build-FSPTestApp-Qt_5_6_35_6_3-Release/FSPTestApp /home/platform-dev/projects/FSP/FSPTestApp
#   cp -r /home/platform-dev/projects/FSP/FSPTestApp ../rootfs/home/root/bin
	
	echo "Operation successful."
else 
	echo "File copy failed" 
fi
