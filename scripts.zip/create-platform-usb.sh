#!/bin/bash

get_files_and_tar()
{
    echo "#####COPYING-BOOT-RFS-APP-DATA-TAR#########"
    echo "#####HOLD-ON - THIS TAKES TIME#############"
    mkdir ../usb/output
#    cp -r ../boot ../usb/input/
#    cp -r ../rootfs ../usb/input/
    cp ../usb/input/fsp-image-*.tar.xz .
    mv fsp-image-*.tar.xz rootfs.tar.xz
#    cp -r ../usb/input/* .
    sleep 1
#    tar -zcf boot.tar.gz boot
#    tar -zcf rootfs.tar.gz rootfs
    tar -zcf image.tar.gz rootfs.tar.xz
    rm -rf boot*
    rm -rf rootfs*
    rm -rf app*
    rm -rf data*
    rm -rf ../usb/input/boot
    mv image.tar.gz ../usb/output/
}

sign_and_encrypt()
{
    RED=`tput setaf 1`
    GREEN=`tput setaf 2`
    DEFAULT_COLOR=`tput sgr0`
    CERT_PATH=../usb/signing-certs
    FILE_PATH=../usb/output
    echo "#####GENERATING SIGNATURE##################"
    openssl cms -sign -in ../usb/output/image.tar.gz -out ../usb/output/platform.sig -signer ${CERT_PATH}/client.crt -inkey ${CERT_PATH}/client.key -outform DER -nosmimecap -binary -certfile      ${CERT_PATH}/ca.crt
    if [ $? -eq 0 ]; then
	echo -e "${GREEN}sign success. platform.sig file generated.${DEFAULT_COLOR}"
        sleep 2
        echo "#####VERIFYING SIGNATURE AGAINST IMAGE#####"
        openssl cms -verify -in ../usb/output/platform.sig -content ../usb/output/image.tar.gz -inform DER -binary -CAfile ${CERT_PATH}/ca.crt > /dev/null
        if [ $? -eq 0 ]; then
	    echo -e "${GREEN}verify success.${DEFAULT_COLOR}"
            echo "#####ENCRYPTING IMAGE######################"
            openssl cms -encrypt -binary -in ../usb/output/image.tar.gz -aes256 -out ../usb/output/platform.enc ${CERT_PATH}/client.crt	
            if [ $? -eq 0 ]; then
        	echo -e "${GREEN}encrypt success. platform.enc file generated.${DEFAULT_COLOR}"
                rm -rf ../usb/output/image.tar.gz
	        #exit 0
            else
	        echo -e "${RED}encrypt fail${DEFAULT_COLOR}"
	        exit 1	
            fi
	    #exit 0
        else
	    echo -e "${RED}verify fail${DEFAULT_COLOR}"
	    exit 1	
        fi
	#exit 0
    else
	echo -e "${RED}sign fail.${DEFAULT_COLOR}"
	exit 1
    fi    
}

gen_tar_platform()
{
    echo "#####GENERATING TAR TO BE COPIED TO USB####"
    cp ../usb/output/* .
    rm -rf ../usb/output/*
    #cp ../usb/certs 
    tar -zcf platform.tar.gz platform.sig platform.enc ../usb/certs
    mv platform.tar.gz ../usb/
    rm -rf platform.sig
    rm -rf platform.enc
    sleep 1

    echo "#####NOW COPY platform.tar.gz from usb folder TO USB####"
}

rm -rf ../usb/*.gz
get_files_and_tar
sign_and_encrypt
gen_tar_platform



