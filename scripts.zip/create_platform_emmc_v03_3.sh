check_unmount()
{
echo "Checking the device is unmounted"
#unmount drives if they are mounted
unmounted1=`df | grep '\<'$DEVICEDRIVENAME''p1'\>' | awk '{print $1}'`
unmounted2=`df | grep '\<'$DEVICEDRIVENAME''p2'\>' | awk '{print $1}'`
unmounted3=`df | grep '\<'$DEVICEDRIVENAME''p3'\>' | awk '{print $1}'`
unmounted4=`df | grep '\<'$DEVICEDRIVENAME''p4'\>' | awk '{print $1}'`

if [ -n "$unmounted1" ]
then
	echo " unmounted ${DRIVE}p1"
	sudo umount -f ${DRIVE}p1
fi
if [ -n "$unmounted2" ]
then
	echo " unmounted ${DRIVE}p2"
	sudo umount -f ${DRIVE}p2
fi
if [ -n "$unmounted3" ]
then
	echo " unmounted ${DRIVE}p3"
	sudo umount -f ${DRIVE}p3
fi
if [ -n "$unmounted4" ]
then
	echo " unmounted ${DRIVE}p4"
	sudo umount -f ${DRIVE}p4
fi
echo ""
}

erase_emmc_partition()
{
	dd if=/dev/zero of=${DRIVE}p4 bs=1M count=2408
	SIZE=`fdisk -l ${DRIVE}p4 | grep Disk | awk '{print $5}'`
	echo DISK SIZE - $SIZE bytes
        echo "-----------------------------"

	sleep 10
	dd if=/dev/zero of=${DRIVE}p3 bs=1M count=1024
	SIZE=`fdisk -l ${DRIVE}p3 | grep Disk | awk '{print $5}'`
	echo DISK SIZE - $SIZE bytes

	sleep 10
	dd if=/dev/zero of=${DRIVE}p2 bs=1M count=1024
	SIZE=`fdisk -l ${DRIVE}p2 | grep Disk | awk '{print $5}'`
	echo DISK SIZE - $SIZE bytes
        echo "-----------------------------"

	sleep 10
	dd if=/dev/zero of=${DRIVE}p1 bs=1M count=100
	SIZE=`fdisk -l ${DRIVE}p1 | grep Disk | awk '{print $5}'`
	echo DISK SIZE - $SIZE bytes
        echo "-----------------------------"

	#lsblk

	check_unmount

sfdisk "${DRIVE}" <<-__EOF__

			 ,100M,c,*
			 ,1.5G,L
                         ,1.5G,L
                       ;
__EOF__
        echo "-----------------------------"
	check_unmount
}

emmc_create_partition()
{
	check_unmount		

	dd if=/dev/zero of=$DRIVE bs=1M count=1024
	SIZE=`fdisk -l $DRIVE | grep Disk | awk '{print $5}'`
	echo DISK SIZE - $SIZE bytes

	sleep 10

	lsblk

    	check_unmount

sfdisk "${DRIVE}" <<-__EOF__

			 ,100M,c,*
			 ,1.5G,L
                         ,1.5G,L
                       ;
__EOF__
        echo "-----------------------------"
	check_unmount
}

emmc_create_filesystem_lable()
{
#      message="mkfs.ext4 /dev/mmcblk1p1 -L root" ; broadcast

        echo "------------creating labels----------------"
        mkfs.vfat -F 32 -n "boot" ${DRIVE}p1
        sleep 10;sync

        mkfs.ext4 -O 64bit -F ${DRIVE}p2 -L "Root"
        sleep 10;sync

        mkfs.ext4 -O 64bit -F ${DRIVE}p3  -L "Backup_root"
        sleep 10;sync

        mkfs.ext4 -O 64bit -F ${DRIVE}p4 -L "Upgrade"
        sleep 10;sync
        echo "-------------------------------------------"
}

emmc_copy_boot_rootfs()
{
	PWD=`pwd`
        echo "-----------------------------"
	# Make temporary directories and untar mount the partitions
        mkdir /media/$USER/
        mkdir /media/$USER/boot
        mkdir /media/$USER/rootfs
        mkdir /media/$USER/rootfs_back
	mount -t vfat "${DRIVE}"p"1" /media/$USER/boot
        mount -t ext4 "${DRIVE}"p"2" /media/$USER/rootfs
        mount -t ext4 "${DRIVE}"p"3" /media/$USER/rootfs_back
        echo "------------------------------------"

        echo "------------------------------------"
        echo "--------Copying boot files----------"
	cp $PWD/boot/MLO 	    /media/$USER/boot/
	cp $PWD/boot/u-boot.img	    /media/$USER/boot/
	cp $PWD/boot/uEnv.txt       /media/$USER/boot/
        echo "------------------------------------"


        echo "-----------------------------------------"
        echo "---------Copying rootfs files------------"
	tar -xf fsp-image-test-*.tar.xz -C /media/$USER/rootfs
        echo "-------Copying rootfs_back files---------"
	tar -xf fsp-image-test-*.tar.xz -C /media/$USER/rootfs_back
        echo "-----------------------------------------"

	umount /media/$USER/boot /media/$USER/rootfs /media/$USER/rootfs_back
        sync;sleep 10;sync;sleep 10;sync

       # Clean up the temp directories
        rm -rf /media/$USER/boot /media/$USER/rootfs /media/$USER/rootfs_back /media/$USER
}

cat << EOM
################################################################################
This script will create emmc partitions and copy the custom or pre-built binaries.
The script must be run with root permissions and from the bin directory of
the SDK
Example:
 $ sudo ./create_platform_emmc.sh
Formatting can be skipped if the SD card is already formatted and
partitioned properly.
################################################################################
EOM

############ checking sudo user or not ? ######################################

AMIROOT=`whoami | awk {'print $1'}`
if [ "$AMIROOT" != "root" ] ; then

	echo "	**** Error *** must run script with sudo"
	echo ""
	exit
fi


# find the avaible SD cards
echo " "
echo "Availible Drives to write images to: "
echo " "
ROOTDRIVE=`mount | grep 'on / ' | awk {'print $1'} |  cut -c6-8`
echo "#  major   minor    size   name "
cat /proc/partitions | grep -v $ROOTDRIVE | grep '\<mmcblk0\>' | grep -n ''
echo " "


ENTERCORRECTLY=0
while [ $ENTERCORRECTLY -ne 1 ]
do
	#read -p 'Enter Device Number: ' DEVICEDRIVENUMBER
	#echo " "
	DEVICEDRIVENAME=`cat /proc/partitions | grep '\<mmcblk0\>' |  grep -n '' |  awk '{print $5}'`

	DRIVE=/dev/$DEVICEDRIVENAME
	DEVICESIZE=`cat /proc/partitions | grep '\<mmcblk0\>' |  grep -n '' |  awk '{print $4}'`


	if [ -n "$DEVICEDRIVENAME" ]
	then
		ENTERCORRECTLY=1
	else
		echo "Invalid selection"
	fi

	echo ""
done

#echo "$DEVICEDRIVENAME was selected"
#Check the size of disk to make sure its under 16GB
if [ $DEVICESIZE -gt 17000000 ]; then
cat << EOM
################################################################################
		**********WARNING**********
	Selected Device is greater then 16GB
	Continuing past this point will erase data from device
	Double check that this is the correct SD Card
################################################################################
EOM

fi

echo ""

DRIVE=/dev/$DEVICEDRIVENAME

# check to see if the device is already partitioned
SIZE1=`cat /proc/partitions |  grep '\<'$DEVICEDRIVENAME''p1'\>'  | awk '{print $3}'`
SIZE2=`cat /proc/partitions |  grep '\<'$DEVICEDRIVENAME''p2'\>'  | awk '{print $3}'`
SIZE3=`cat /proc/partitions |  grep '\<'$DEVICEDRIVENAME''p3'\>'  | awk '{print $3}'`
SIZE4=`cat /proc/partitions |  grep '\<'$DEVICEDRIVENAME''p4'\>'  | awk '{print $3}'`
echo "${DEVICEDRIVENAME}p1  ${DEVICEDRIVENAME}p2  ${DEVICEDRIVENAME}p3 ${DEVICEDRIVENAME}p4"
echo $SIZE1 $SIZE2 $SIZE3 $SIZE4
echo ""

PARTITION="0"
if [ -n "$SIZE1" -a -n "$SIZE2" ] ; then
	if  [ "$SIZE1" -gt "100000" -a "$SIZE2" -gt "1500000" ]
	then
		PARTITION=1
		if [ -n "$SIZE3" -a -n "$SIZE4" ]
		then
			#Detected 2 partitions
			PARTS=2
			if [ "$SIZE3" -gt "1500000" -a "$SIZE4" -gt "4000000" ]
			then
			#Detected 3 partitions
			PARTS=3
			else
				echo "SD Card is not correctly partitioned"
				PARTITION=0
			fi
		fi
	fi
else
	echo "SD Card is not correctly partitioned"
	PARTITION=0
	PARTS=0
fi


#Partition is not found create 4 partitions
if [ "$PARTITION" -eq "0" ]
then
cat << EOM
################################################################################
		Now making 4 partitions 
################################################################################
EOM
	check_unmount
	emmc_create_partition
fi
#Partition is found
if [ "$PARTITION" -eq "1" ]
then
cat << EOM
################################################################################
   Detected device has $PARTS partitions already
   erasing the contents of all partitions and recreate partitions again.
################################################################################
EOM
	check_unmount
	erase_emmc_partition
fi
	emmc_create_filesystem_lable
	emmc_copy_boot_rootfs
