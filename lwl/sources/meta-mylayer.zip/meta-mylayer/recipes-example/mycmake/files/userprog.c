#include <stdio.h>

int main()
{
	printf("Hello Cmake\n");
	return 0;
}
